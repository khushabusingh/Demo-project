package demos.springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringDataJpaDemo1Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringDataJpaDemo1Application.class, args);
	}

}
