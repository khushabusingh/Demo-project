import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AboutComponent } from './about/about.component';
import { AddCategoryComponent } from './category/add-category/add-category.component';
import { CategoryListComponent } from './category/category-list/category-list.component';
import { CategoryComponent } from './category/category.component';
import { DeleteCategoryComponent } from './category/delete-category/delete-category.component';
import { UpdateCategoryComponent } from './category/update-category/update-category.component';
import { ContactComponent } from './contact/contact.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { HomeComponent } from './home/home.component';
import { AddProductComponent } from './product/add-product/add-product.component';
import { DeleteProductComponent } from './product/delete-product/delete-product.component';
import { ProductListComponent } from './product/product-list/product-list.component';
import { ProductComponent } from './product/product.component';
import { UpdateProductComponent } from './product/update-product/update-product.component';
import { SellerDashboardComponent } from './seller/seller-dashboard/seller-dashboard.component';
import { SellerHomeComponent } from './seller/seller-home/seller-home.component';
import { SellerLoginComponent } from './seller/seller-login/seller-login.component';
import { SellerLogoutComponent } from './seller/seller-logout/seller-logout.component';
import { SellerComponent } from './seller/seller.component';
import { ServicesComponent } from './services/services.component';
import { TeamComponent } from './team/team.component';


const routes: Routes = [
  {path:"dashboard", component: DashboardComponent,
    children: [
    {path:"home", component:HomeComponent},
    {path:"about", component:AboutComponent},
    {path:"services", component:ServicesComponent},
    {path:"team", component:TeamComponent},
    {path:"contact", component:ContactComponent},
  ]
},

 
  
  {path:"product", component: ProductComponent, 
    children: [
      {path:"show-all-products", component: ProductListComponent},
      {path:"add-product", component: AddProductComponent},
      {path:"update-product", component: UpdateProductComponent},
      {path:"delete-product", component: DeleteProductComponent},
    ]
  },

  {path:"category", component: CategoryComponent, 
    children: [
      {path:"show-all-categories", component: CategoryListComponent},
      {path:"add-category", component: AddCategoryComponent},
      {path:"update-category/:id", component: UpdateCategoryComponent},
      {path:"delete-category/:id", component: DeleteCategoryComponent},
    ]
  },

  {path:"seller", component: SellerComponent,
    children: [
      {path:"login", component: SellerLoginComponent},
      {path:"logout", component: SellerLogoutComponent},
      {path:"dashboard", component: SellerDashboardComponent},  
      {path:"home", component: SellerHomeComponent},
      
    ]

  }
  
];  

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
