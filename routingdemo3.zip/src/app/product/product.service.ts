import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Category } from '../category/category';
import { Product } from './product';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';


@Injectable({
  providedIn: 'root'
})
export class ProductService {

  private products: Product[] = [];

  constructor(private _httpClient: HttpClient) { 
    /*this.products = [
      new Product(101, '43 inch LED TV', new Category(1, 'Electronics', 'All Electronic Products'), 'Samsung', 40000),
      new Product(102, '53 inch LED TV', new Category(1, 'Electronics', 'All Electronic Products'), 'Samsung', 42000),
      new Product(103, 'Inverter AC', new Category(1, 'Electronics', 'All Electronic Products'), 'LG', 38000),
      new Product(104, 'Intverter AC', new Category(1, 'Electronics', 'All Electronic Products'), 'LG', 45000),
      new Product(105, 'Microwave', new Category(1, 'Electronics', 'All Electronic Products'), 'Microtek', 50000),
    ];*/

    /*this.products = [
      new Product(101, '43 inch LED TV',  'Samsung', 40000),
      new Product(102, '53 inch LED TV',  'Samsung', 42000),
      new Product(103, 'Inverter AC',  'LG', 38000),
      new Product(104, 'Intverter AC', 'LG', 45000),
      new Product(105, 'Microwave', 'Microtek', 50000),
    ];*/
  }

  getAllProducts(): Observable<Product[]> {
    let url: string = "http://localhost:9090/api/products";

    return this._httpClient.get<Product[]>(url).pipe(map(response => response));
  }

  addProduct(product: Product): Observable<Product> {
    let url: string = "http://localhost:9090/api/categories/1/products";
    return this._httpClient.post<Product>(url, product).pipe(map(response => response));
  }
}
