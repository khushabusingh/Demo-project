import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Category } from 'src/app/category/category';
import { CategoryService } from 'src/app/category/category.service';
import { Product } from '../product';
import { ProductService } from '../product.service';

@Component({
  selector: 'app-add-product',
  templateUrl: './add-product.component.html',
  styleUrls: ['./add-product.component.css']
})
export class AddProductComponent implements OnInit {

  product: Product = new Product(0, "", new Category(0,"",""),"", 0.0, null, null);
  
  message: string = "";

  categories: Category[] = [];



  constructor(private service: ProductService,  private categoryService: CategoryService, private router: Router ) { 
    
  }

  ngOnInit() {
    this.categoryService.getAllCategories().subscribe(data => {
      this.categories = data;
      console.log(this.categories);
    }, error => {
      alert("Problem fetching categories");  
    })
    
    
  }

  onsubmit() {
    console.log(this.product);

    let categoryName = this.product.category.categoryName;

    this.categories.forEach(category => {
      if(category.categoryName === categoryName) {
        this.product.category.categoryId = category.categoryId;
      }
    })
   
    
    this.service.addProduct(this.product).subscribe(data => {
      console.log(data);
      if(data) {
        //this.message = "Product added successfully";
        alert("Product added successfully");
        this.router.navigateByUrl("/product/show-all-products");

      }
      else {
        //this.message = "Problem adding product";
        alert("Problem adding product");
        this.router.navigateByUrl("/product/show-all-products");
      }
      //this.product = new Product(0,"","",0.0);

    })
  }

}
