import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { Category } from './category';

@Injectable({
  providedIn: 'root'
})
export class CategoryService {

  private categories: Category[] = [];

  constructor(private _httpClient: HttpClient) {     
    
  }

  getAllCategories(): Observable<Category[]> {
    let url: string = "http://localhost:9090/api/categories";

    return this._httpClient.get<Category[]>(url).pipe(map(response => response));
  }

  addCategory(category: Category): Observable<Category> {
    let url: string = "http://localhost:9090/api/categories/";
    return this._httpClient.post<Category>(url, category).pipe(map(response => response));
  }

  getCategory(categoryId: number): Observable<Category> {
    let url: string = "http://localhost:9090/api/categories/"+categoryId;
    return this._httpClient.get<Category>(url).pipe(map(response => response));
  }

  updateCategory(category: Category): Observable<Category> {
    let url: string = "http://localhost:9090/api/categories/"+category.categoryId;
    return this._httpClient.put<Category>(url, category).pipe(map(response => response));
  }

  deleteCategory(categoryId: number): Observable<boolean> {
    let url: string = "http://localhost:9090/api/categories/"+categoryId;
    return this._httpClient.delete<boolean>(url).pipe(map(response => response));
  }




}
