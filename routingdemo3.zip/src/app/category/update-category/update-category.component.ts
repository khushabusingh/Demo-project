import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Category } from '../category';
import { CategoryService } from '../category.service';

@Component({
  selector: 'app-update-category',
  templateUrl: './update-category.component.html',
  styleUrls: ['./update-category.component.css']
})
export class UpdateCategoryComponent implements OnInit {

  categoryId: number = 0;
  category: Category = null;
  

  constructor(private activatedRoute: ActivatedRoute, private service: CategoryService, private router: Router) { }

  ngOnInit() {

    let catId: number = 0;
    this.activatedRoute.params.subscribe(data => {
      this.categoryId = data.id;

      this.service.getCategory(this.categoryId).subscribe(response => {
        console.log(response);
        this.category = response;
      }, 
      error => {
        alert(error.message);
      })

    })
  }

  onupdate() {
    this.service.updateCategory(this.category).subscribe(data => {
      console.log(data);
      alert("Category updated successfully");
      this.router.navigateByUrl("/category/show-all-categories");
    }, error => {
      console.log(error.message);
      //some more code of your choice
    })
  }



}
