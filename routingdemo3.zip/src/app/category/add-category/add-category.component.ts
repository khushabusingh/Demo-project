import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Category } from '../category';
import { CategoryService } from '../category.service';

@Component({
  selector: 'app-add-category',
  templateUrl: './add-category.component.html',
  styleUrls: ['./add-category.component.css']
})
export class AddCategoryComponent implements OnInit {

  category: Category = new Category(0, "", "");
  message: string = "";


  constructor(private service: CategoryService, private router: Router) { }

  ngOnInit() {
  }

  onsubmit() {
    console.log(this.category);
    this.service.addCategory(this.category).subscribe(data => {
      console.log(data);
      if(data) {
        //this.message = "Product added successfully";
        alert("Category added successfully");
        this.category = new Category(0, "", "");

        //this.router.navigateByUrl("/category/show-all-categories");

      }
     /* else {
        //this.message = "Problem adding category";
        alert("Problem adding category");
        this.router.navigateByUrl("/product/show-all-categories");
      }*/
    },
    error => {
      console.log(error);
      
      //this.message = error.message;
      //alert("Problem adding category");
      alert(error.message);
      this.router.navigateByUrl("/product/show-all-categories");

    })
  }

}
