import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Category } from '../category';
import { CategoryService } from '../category.service';

@Component({
  selector: 'app-delete-category',
  templateUrl: './delete-category.component.html',
  styleUrls: ['./delete-category.component.css']
})
export class DeleteCategoryComponent implements OnInit {

  categoryId: number = 0;
  category: Category = null;
  

  constructor(private activatedRoute: ActivatedRoute, private service: CategoryService, private router: Router) { }

  ngOnInit() {

    
    this.activatedRoute.params.subscribe(data => {
      this.categoryId = data.id;

      this.service.deleteCategory(this.categoryId).subscribe(data => {
        console.log(data);
        alert("Category deleted successfully");
        this.router.navigateByUrl("/category/show-all-categories");
      }, error => {
        console.log(error.message);
        
      })

    })
  }

  

}
