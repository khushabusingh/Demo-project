export class Category {
    constructor(public categoryId: number, public categoryName: string, public description: string) {
        
    }
}
