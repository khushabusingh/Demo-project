import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { AboutComponent } from './about/about.component';
import { ServicesComponent } from './services/services.component';
import { TeamComponent } from './team/team.component';
import { ContactComponent } from './contact/contact.component';
import { ProductComponent } from './product/product.component';
import { ProductListComponent } from './product/product-list/product-list.component';
import { AddProductComponent } from './product/add-product/add-product.component';
import { UpdateProductComponent } from './product/update-product/update-product.component';
import { DeleteProductComponent } from './product/delete-product/delete-product.component';
import { FormsModule } from '@angular/forms';
import { CategoryComponent } from './category/category.component';
import { AddCategoryComponent } from './category/add-category/add-category.component';
import { UpdateCategoryComponent } from './category/update-category/update-category.component';
import { DeleteCategoryComponent } from './category/delete-category/delete-category.component';
import { CategoryListComponent } from './category/category-list/category-list.component';
import { SellerComponent } from './seller/seller.component';
import { SellerLoginComponent } from './seller/seller-login/seller-login.component';
import { SellerRegistrationComponent } from './seller/seller-registration/seller-registration.component';
import { SellerHomeComponent } from './seller/seller-home/seller-home.component';
import { SellerNavbarComponent } from './seller/seller-navbar/seller-navbar.component';
import { SellerDashboardComponent } from './seller/seller-dashboard/seller-dashboard.component';
import { SellerLogoutComponent } from './seller/seller-logout/seller-logout.component';
import { DashboardComponent } from './dashboard/dashboard.component';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    AboutComponent,
    ServicesComponent,
    TeamComponent,
    ContactComponent,
    ProductComponent,
    ProductListComponent,
    AddProductComponent,
    UpdateProductComponent,
    DeleteProductComponent,
    CategoryComponent,
    AddCategoryComponent,
    UpdateCategoryComponent,
    DeleteCategoryComponent,
    CategoryListComponent,
    SellerComponent,
    SellerLoginComponent,
    SellerRegistrationComponent,
    SellerHomeComponent,
    SellerNavbarComponent,
    SellerDashboardComponent,
    SellerLogoutComponent,
    DashboardComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
