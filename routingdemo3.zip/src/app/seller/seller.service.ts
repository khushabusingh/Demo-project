import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class SellerService {

  private loggedInFlag: boolean = false;

  constructor() { }

  isLoggedIn():boolean {
    return this.loggedInFlag;
  }

  setLoggedInFlag(value: boolean):void {
    this.loggedInFlag = value;
  }
}
