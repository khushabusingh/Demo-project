import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-seller-registration',
  templateUrl: './seller-registration.component.html',
  styleUrls: ['./seller-registration.component.css']
})
export class SellerRegistrationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
