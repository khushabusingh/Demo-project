import { Component, OnInit } from '@angular/core';
import { SellerService } from './seller.service';

@Component({
  selector: 'app-seller',
  templateUrl: './seller.component.html',
  styleUrls: ['./seller.component.css']
})
export class SellerComponent implements OnInit {

  private loggedInFlag: boolean = false;

  constructor(private sellerService: SellerService) { }

  ngOnInit() {
    this.loggedInFlag = this.sellerService.isLoggedIn();
  }

}
