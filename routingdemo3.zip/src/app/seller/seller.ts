export class Seller {
    constructor(public username: string, public password: string){
    }
}
