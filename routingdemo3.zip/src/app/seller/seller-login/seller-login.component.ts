import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Seller } from '../seller';
import { SellerService } from '../seller.service';

@Component({
  selector: 'app-seller-login',
  templateUrl: './seller-login.component.html',
  styleUrls: ['./seller-login.component.css']
})
export class SellerLoginComponent implements OnInit {

  seller: Seller = new Seller("","");

  constructor(private router: Router, private sellerService: SellerService) { }

  ngOnInit() {   
  }

  onsubmit() {
    if(this.seller.username === 'Rahul' && this.seller.password === '123456') {
      alert("Login Successful")
      //this.sellerService.setLoggedInFlag(true);
      window.sessionStorage.setItem("loggedin-username",this.seller.username);
      window.sessionStorage.setItem("loggedin-status","loggedin");
      this.router.navigateByUrl("seller/dashboard");
    }
    else {
      alert("Incorrect username or password");
    }
  }

}
